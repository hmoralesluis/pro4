<div id="top-banner-and-menu" class="homepage2">
    <!--container-->
    <div class="container" >
        <div class="col-xs-12">
            <!-- ========================================== SECTION – HERO ========================================= -->

            <div id="hero">
                <div id="owl-main" class="owl-carousel height-sm owl-inner-nav owl-ui-md">

                    <div class="item" style="background-image: url(shop/assets/images/sliders/slider01.jpg);">
                        <div class="container-fluid">
                            <div class="caption vertical-center text-right right" style="padding-right:0;">
                                <div class="big-text fadeInDown-1">
                                    <span class="big">GLOBAL INDUSTRIAL </span> <span class="medium"><span class="sign"></span> AUTOMATION SUPPLIERS</span>
                                </div>
                            </div><!-- /.caption -->
                        </div><!-- /.container-fluid -->
                    </div><!-- /.item -->

                    <div class="item" style="background-image: url(shop/assets/images/sliders/slider03.jpg);">
                        <div class="container-fluid">
                            <div class="caption vertical-center text-left left" style="padding-right:0;">
                                <div class="big-text fadeInDown-1">
                                    <span class="big">GLOBAL INDUSTRIAL </span> <span class="medium"><span class="sign"></span> AUTOMATION SUPPLIERS</span>
                                </div>
                            </div><!-- /.caption -->
                        </div><!-- /.container-fluid -->
                    </div><!-- /.item -->

                    <div class="item" style="background-image: url(shop/assets/images/sliders/slider02.jpg);">
                        <div class="container-fluid">
                            <div class="caption vertical-center text-right right" style="padding-right:0;">
                                <div class="big-text fadeInDown-1">
                                    <span class="big">GLOBAL INDUSTRIAL </span> <span class="medium"><span class="sign"></span> AUTOMATION SUPPLIERS</span>
                                </div>
                            </div><!-- /.caption -->
                        </div><!-- /.container-fluid -->
                    </div><!-- /.item -->


                    <div class="item" style="background-image: url(shop/assets/images/sliders/slider04.jpg);">
                        <div class="container-fluid">
                            <div class="caption vertical-center text-left left" style="padding-right:0;">
                                <div class="big-text fadeInDown-1">
                                    <span class="big">GLOBAL INDUSTRIAL </span> <span class="medium"><span class="sign"></span> AUTOMATION SUPPLIERS</span>
                                </div>
                            </div><!-- /.caption -->
                        </div><!-- /.container-fluid -->
                    </div><!-- /.item -->



                </div><!-- /.owl-carousel -->
            </div>

            <!-- ========================================= SECTION – HERO : END ========================================= -->
        </div>
    </div>
</div><!-- /.homepage2 -->

<!-- ========================================= HOME BANNERS ========================================= -->
<section id="banner-holder" class="wow fadeInUp">
    <div class="container">
        <div class="row marketing">
            <h5 class=" h3 text-center text-about-green">
                Our company provides</br>
                automation spare, parts, and pieces for control systems(PLC) installed.</br></br>
                Our mission is help you to:
            </h5>
        </div>
        </br>
        <div class="col-xs-12 col-lg-3 no-margin  ">
             <div class="row">
                 <div class="col-xs-12"> <p>  <img class="marketing-image" alt="" src="shop/assets/images/blank.gif" data-echo="shop/assets/images/banners/round1.png" /></p></div>

                 <div class="col-xs-12"> <span class="text-center-home">Reduce your maintenance costs.</span> </div>
             </div>
        </div>

        <div class="col-xs-12 col-lg-3 no-margin  ">
            <div class="row">

                <div class="col-xs-12"><p><img class="marketing-image " alt="" src="shop/assets/images/blank.gif" data-echo="shop/assets/images/banners/round2.png" /> </p></div>

                    <div class="col-xs-12">   <p class="text-center-home ">Eficient migrate to new technology..</p></div>
                    </div>
        </div>

        <div class="col-xs-12 col-lg-3 no-margin ">
            <div class="row">
            <div class="col-xs-12"> <p> <img class="marketing-image" alt="" src="shop/assets/images/blank.gif" data-echo="shop/assets/images/banners/round3.png" />  </p></div>
                <div class="col-xs-12">   <p class="text-center-home">Extend the life of your control system.</p></div>
            </div>

        </div>

        <div class="col-xs-12 col-lg-3 no-margin ">
            <div class="row">
            <div class="col-xs-12"> <p> <img class=" marketing-image" alt="" src="shop/assets/images/blank.gif" data-echo="shop/assets/images/banners/round4.png" /> </p></div>

                <div class="col-xs-12"> <p class="text-center-home">Reduce interrumption times of any control system.</p></div>
            </div>
        </div>

    </div><!-- /.container -->
</section><!-- /#banner-holder -->
<!-- ========================================= HOME BANNERS : END ========================================= -->

<script type="text/javascript">
    $('#owl-main').carousel({
        interval: 2000,
        wrap: true
    })


</script>
